#include <stdio.h>

/*
===========================================
    HÀM TÍNH TỔNG CHỮ SỐ — ITERATION
===========================================
Độ phức tạp: 
- Mỗi lần tính chỉ duyệt qua số chữ số của n → O(log n).
*/
int sumDigits_iter( int n) {
    int sum = 0;
    while ( n > 0) {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

/*
======================================================
    HÀM TÌM CÁC HARSHAD NUMBER TỪ 1 → n (ITERATION)
======================================================
Độ phức tạp tổng:
- Lặp từ 1 đến n → O(n)
- Mỗi lần gọi sumDigits_iter → O(log n)
→ Tổng: O(n log n)
*/
void harshad_iter(   int n) {



    printf("Harshad numbers (Iteration): ");
    for (   int i = 1; i <= n; i++) {
        int sum = sumDigits_iter(i);
        if (i % sum == 0)
            printf("%d ", i);
    }
    printf("\n");
}

/*
===========================================
    HÀM TÍNH TỔNG CHỮ SỐ — RECURSION
===========================================
Độ phức tạp:
- Mỗi lần chia n/10 → số bước = số chữ số → O(log n)
*/
int sumDigits_rec(int n) {
    if (n == 0) return 0;
    return (n % 10 ) + sumDigits_rec(n / 10);
}

/*
===========================================
    HÀM KIỂM TRA HARSHAD — RECURSION
===========================================
*/
int isHarshad_rec(int n) {
    int sum = sumDigits_rec(n);
    return (n % sum == 0);
}

/*
Độ phức tạp:
- Gọi n lần → O(n)
- Mỗi lần tính tổng chữ số → O(log n)
→ Tổng: O(n log n)
*/
void harshad_rec(int current, int n) {
    if (current > n) return;

    if (isHarshad_rec( current))
        printf("%d ", current);

    harshad_rec(current + 1, n);  
}

int main() {
    int n = 100;


    harshad_iter(n);

    printf("Harshad numbers (Recursion): ");
    harshad_rec(1, n);

    return 0;
}
