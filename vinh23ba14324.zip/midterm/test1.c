/*
Question 1 (16 pts)
A Harshad number is an integer that is divisible by the sum of its digits.
Example:
- 18/(1+8) = 18/9 = 2, 18 is divisible by 2 → Harshad number.
- 21/(2+1) = 21/3 = 7, divisible → Harshad number.
- 19/(1+9) = 19/10 = 1.919, not divisible → not a Harshad number.
- 274/(2+7+4) = 274/13 = 21.07, not divisible → not a Harshad number.
▪ Implement a program in C/C++ using Iteration to find all Harshad numbers from 1 to n (n is
a natural number). (7pts)
▪ Implement another function using Recursion to complete the above question. (7pts)
▪ Calculate the complexity of your functions or algorithms. Justify the answer (comment
directly in your source files). (2pts)*/
#include<stdio.h>


int sumrec(int n ){
    if(n ==0 ) return 0;
    return n%10 + sumrec(n/10);              //O(n)
}
int checkHarshad(int n){
    if (n <= 0) return 0;
    int sum = 0;
    int tmp = n;
    while (tmp > 0){                         //O(n)
        sum += tmp % 10;
        tmp /= 10;
    }
    if(sum != 0  && n%sum ==0) return 1;
    return 0;
}

int main(){
    int n = 274;


    for(int i = 1 ; i <= n ; i++){
        if (checkHarshad(i) == 1) printf("%d ", i);//O(n^2)
    }
    printf("\n");
    for(int i = 1; i <=n ; i++){
        int s = sumrec(i);
        if(s != 0 && i %s ==0) printf("%d ", i);//O(n^2)
    }

    return 0;
}